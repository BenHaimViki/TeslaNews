//
//  Source.swift
//  FidoNews
//
//  Created by viki benhaim on 28/08/2022.
//

import Foundation

struct Source: Decodable {
    var id: String?
    var name: String
}
