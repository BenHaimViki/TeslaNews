//
//  NewsServices.swift
//  FidoNews
//
//  Created by viki benhaim on 28/08/2022.
//

import Foundation

class NewsServices {
    
    static func loadNewsList(url: String, completionHandler: @escaping ([Article]?, Bool?) -> Void) {
        Network.loadData(url: url, type: ListArticles.self) { (listArticles, error) in
            guard error == nil else {
              completionHandler(nil, false)
              return
            }
            
            completionHandler(listArticles?.articles, true)
        }
    }
}
