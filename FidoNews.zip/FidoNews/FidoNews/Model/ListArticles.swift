//
//  ListArticles.swift
//  FidoNews
//
//  Created by viki benhaim on 28/08/2022.
//

import Foundation

struct ListArticles: Decodable {
    var status: String
    var totalResults: Int
    var articles: [Article]
}


