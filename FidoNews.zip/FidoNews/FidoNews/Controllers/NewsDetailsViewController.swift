//
//  NewsDetailsViewController.swift
//  FidoNews
//
//  Created by viki benhaim on 28/08/2022.
//

import UIKit

class NewsDetailsViewController: UIViewController {

    @IBOutlet weak var contentArticle: UILabel!
    @IBOutlet weak var titleArticle: UILabel!
    @IBOutlet weak var descriptionArticle: UILabel!
    
    var article: Article?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
      super.viewWillAppear(animated)
      
        titleArticle.text = article?.title
        contentArticle.text = article?.content
        descriptionArticle.text = article?.description
    }
    
    @IBAction func closeArticle(_ sender: Any) {
        dismiss(animated: true)
    }
    
}
