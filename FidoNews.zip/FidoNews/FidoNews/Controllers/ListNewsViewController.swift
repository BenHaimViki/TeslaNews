//
//  ViewController.swift
//  FidoNews
//
//  Created by viki benhaim on 28/08/2022.
//

import UIKit

class ListNewsViewController: UIViewController {
    
    @IBOutlet var tableView: UITableView!
    @IBOutlet weak var progressLoading: UIProgressView!
    
    private var myTimer: Timer?
    private var shouldNewsDetailsViewControllerDismiss = false
    private let progress = Progress()
    
    var articles : [Article]? {
        didSet {
            if isViewLoaded {
                tableView.reloadData()
                myTimer?.invalidate()
                progressLoading.progress = 0.0
            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myTimer = Timer()
        progressLoading.progress = 0.0
        
        let nc = NotificationCenter.default
        
        nc.addObserver(self, selector: #selector(appMovedToForeground), name: UIApplication.willEnterForegroundNotification, object: nil)
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if shouldNewsDetailsViewControllerDismiss {
            //details view controller is dismissed
            loadDataFromApi()
        }
        shouldNewsDetailsViewControllerDismiss = false
        
    }
    
    
    @objc func appMovedToForeground() {
        loadDataFromApi()
    }
    
    func loadDataFromApi() {
        print("Load dtata from api")
        
        startLoadingAnimation()
        
        NewsServices.loadNewsList(url: "https://newsapi.org/v2/everything?q=tesla&from=2022-07-28&sortBy=publishedAt&apiKey=47c520500ddf43da98f8d821ed4e7c3f") { [weak self] (articlesList, isSuccess) in
            
            guard let self = self else { return }
            
            if isSuccess == true {
                self.articles = articlesList
            }
        }
    }
    
    func startLoadingAnimation() {
        myTimer = Timer.scheduledTimer(timeInterval: 0.05, target: self, selector: #selector(ListNewsViewController.updateProgress), userInfo: nil, repeats: true)
    }
    
    @objc func updateProgress() {
        progressLoading.progress += 0.1
        
        if progressLoading.progress >= 1 {
            progressLoading.progress = 0
        }
    }
}
//
// MARK: - Table View Data Source
//
extension ListNewsViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        articles?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let newCell = tableView.dequeueReusableCell(withIdentifier: "NewCell", for: indexPath)
        
        if let article = articles?[indexPath.row] {
            newCell.textLabel?.text = article.title
            newCell.textLabel?.numberOfLines = 3
        }
        
        return newCell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
}

//
// MARK: - Table View Delegate
//
extension ListNewsViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        if let article = articles?[indexPath.row] {
            guard let newsDetailsVC = self.storyboard?.instantiateViewController(withIdentifier: "NewsDetailsViewController") as? NewsDetailsViewController else {
                return
            }
            
            newsDetailsVC.article = article
            
            newsDetailsVC.modalPresentationStyle = .fullScreen
            
            self.present(newsDetailsVC, animated: true) {
                self.shouldNewsDetailsViewControllerDismiss = true
            }
        }
    }
}
